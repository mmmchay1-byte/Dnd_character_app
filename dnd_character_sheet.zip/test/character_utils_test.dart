import 'package:flutter_test/flutter_test.dart';
import 'package:dnd_character_sheet/models/ability.dart';
import 'package:dnd_character_sheet/models/character.dart';
import 'package:dnd_character_sheet/models/character_class.dart';

void main() {
  group('Ability modifier', () {
    test('modifier is calculated according to rules', () {
      expect(AbilityUtils.modifier(10), 0);
      expect(AbilityUtils.modifier(8), -1);
      expect(AbilityUtils.modifier(15), 2);
      expect(AbilityUtils.modifier(18), 4);
    });
  });

  group('Proficiency bonus', () {
    test('proficiency bonus follows table', () {
      // Mock a character class for testing.
      final mockClass = CharacterClass(
        name: 'Test',
        hitDie: 'd8',
        primaryAbilities: [Ability.strength],
        savingThrows: [Ability.strength],
        skillChoices: [],
        numSkillChoices: 0,
        equipmentChoices: [],
        spellcasting: false,
        features: {},
      );
      // Create a minimal race and background to satisfy non‑null constraints.
      final dummyRace = Race(name: 'Human', speed: 30, abilityBonuses: {}, traits: [], subraces: []);
      final dummyBackground = Background(
        name: 'None',
        skillProficiencies: [],
        toolProficiencies: [],
        languages: [],
        equipment: [],
        feature: '',
        personalityTraits: [],
        ideals: [],
        bonds: [],
        flaws: [],
      );
      final char = Character(
        id: '1',
        name: 'Test',
        race: dummyRace,
        background: dummyBackground,
        classLevels: {mockClass: 1},
        abilityScores: {},
      );
      expect(char.proficiencyBonus, 2);
      char.classLevels[mockClass] = 5;
      expect(char.level, 5);
      expect(char.proficiencyBonus, 3);
    });
  });
}