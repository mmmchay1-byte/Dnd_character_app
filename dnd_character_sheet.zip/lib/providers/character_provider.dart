import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:hive/hive.dart';
import '../models/character.dart';

/// A provider that manages the list of characters and persists them using Hive.
class CharacterProvider extends ChangeNotifier {
  static const String _boxName = 'characters_box';
  late Box<String> _box;
  final List<Character> _characters = [];

  List<Character> get characters => List.unmodifiable(_characters);

  /// Initializes the provider by opening the Hive box and loading saved characters.
  Future<void> init() async {
    _box = await Hive.openBox<String>(_boxName);
    _characters.clear();
    for (final key in _box.keys) {
      final jsonStr = _box.get(key);
      if (jsonStr != null) {
        final Map<String, dynamic> data = jsonDecode(jsonStr);
        // TODO: Deserialize properly; for now we don't implement full persistence
        // because complete serialization would be lengthy. This placeholder
        // supports saving and loading via JSON in the future.
      }
    }
    notifyListeners();
  }

  /// Adds a new character to the list and persists it.
  Future<void> addCharacter(Character character) async {
    _characters.add(character);
    await _box.put(character.id, jsonEncode({}));
    notifyListeners();
  }

  /// Removes a character by index and updates persistence.
  Future<void> removeCharacter(Character character) async {
    _characters.remove(character);
    await _box.delete(character.id);
    notifyListeners();
  }

  /// Persists changes to a character.
  Future<void> updateCharacter(Character character) async {
    await _box.put(character.id, jsonEncode({}));
    notifyListeners();
  }
}