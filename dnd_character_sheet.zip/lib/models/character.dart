import 'dart:math';

import 'ability.dart';
import 'character_class.dart';
import 'race.dart';
import 'background.dart';
import 'spell.dart';
import 'skill.dart';

/// Represents a full D&D 5e character, including race, class(es), background,
/// ability scores, proficiencies and equipment.
class Character {
  final String id;
  String name;
  Race race;
  Subrace? subrace;
  Background background;
  /// Map of class name to number of levels in that class for multiclassing.
  Map<CharacterClass, int> classLevels;
  Map<Ability, int> abilityScores;
  /// Skills in which the character is proficient.
  Map<String, bool> skillProficiencies;
  /// Optional expertise on skills (doubles proficiency bonus).
  Map<String, bool> skillExpertise;
  List<String> equipment;
  List<Spell> knownSpells;
  List<Spell> preparedSpells;

  Character({
    required this.id,
    required this.name,
    required this.race,
    this.subrace,
    required this.background,
    required this.classLevels,
    required this.abilityScores,
    Map<String, bool>? skillProficiencies,
    Map<String, bool>? skillExpertise,
    List<String>? equipment,
    List<Spell>? knownSpells,
    List<Spell>? preparedSpells,
  })  : skillProficiencies = skillProficiencies ?? {},
        skillExpertise = skillExpertise ?? {},
        equipment = equipment ?? [],
        knownSpells = knownSpells ?? [],
        preparedSpells = preparedSpells ?? [];

  /// Total character level derived from all class levels.
  int get level {
    return classLevels.values.fold(0, (a, b) => a + b);
  }

  /// Returns the proficiency bonus based on the character's total level【773529381107959†L243-L269】.
  int get proficiencyBonus {
    if (level >= 17) return 6;
    if (level >= 13) return 5;
    if (level >= 9) return 4;
    if (level >= 5) return 3;
    return 2;
  }

  /// Computes the total ability score, including racial and subracial bonuses.
  int totalAbilityScore(Ability ability) {
    var base = abilityScores[ability] ?? 10;
    // Apply racial bonuses.
    if (race.abilityBonuses.containsKey(ability)) {
      base += race.abilityBonuses[ability]!;
    }
    if (subrace != null && subrace!.abilityBonuses.containsKey(ability)) {
      base += subrace!.abilityBonuses[ability]!;
    }
    return base;
  }

  /// Returns the modifier for an ability, including racial bonuses【103009663591259†L287-L289】.
  int abilityModifier(Ability ability) {
    return AbilityUtils.modifier(totalAbilityScore(ability));
  }

  /// Calculates the character's maximum hit points based on class hit dice,
  /// level and Constitution modifier.
  int get maxHitPoints {
    int hp = 0;
    final conMod = abilityModifier(Ability.constitution);
    classLevels.forEach((cls, lvl) {
      final dieSides = _parseHitDie(cls.hitDie);
      if (lvl > 0) {
        // First level: maximum die value + CON mod.
        hp += dieSides + conMod;
      }
      if (lvl > 1) {
        // Subsequent levels: average of hit die (half + 1) + CON mod.
        final avg = (dieSides / 2).floor() + 1;
        hp += (lvl - 1) * (avg + conMod);
      }
    });
    return max(1, hp);
  }

  /// Parses the hit die string (e.g. "d8") and returns the number of sides.
  int _parseHitDie(String die) {
    return int.tryParse(die.substring(1)) ?? 8;
  }

  /// Returns whether the character is proficient in a given skill.
  bool isProficientIn(String skillName) {
    return skillProficiencies[skillName] ?? false;
  }

  /// Returns whether the character has expertise in a given skill.
  bool hasExpertiseIn(String skillName) {
    return skillExpertise[skillName] ?? false;
  }

  /// Computes the bonus for a skill check, combining ability modifier and proficiency bonus.
  int skillBonus(String skillName) {
    final def = Skills.all.firstWhere((s) => s.name == skillName);
    final mod = abilityModifier(def.ability);
    if (hasExpertiseIn(skillName)) {
      return mod + proficiencyBonus * 2;
    } else if (isProficientIn(skillName)) {
      return mod + proficiencyBonus;
    } else {
      return mod;
    }
  }

  /// Computes the bonus for a saving throw of the given ability.
  int savingThrowBonus(Ability ability) {
    // Determine if any of the character's classes grant proficiency in this save.
    bool proficient = false;
    for (final entry in classLevels.entries) {
      if (entry.value > 0) {
        if (entry.key.savingThrows.contains(ability)) {
          proficient = true;
          break;
        }
      }
    }
    final mod = abilityModifier(ability);
    return mod + (proficient ? proficiencyBonus : 0);
  }
}