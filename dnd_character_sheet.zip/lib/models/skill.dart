import 'ability.dart';

/// Represents a single skill in D&D 5e.
class SkillDefinition {
  final String name;
  final Ability ability;

  const SkillDefinition(this.name, this.ability);
}

/// A map of all standard skills and the ability they are tied to.
///
/// Skills provide a bonus equal to the relevant ability modifier plus the
/// proficiency bonus if the character is proficient【103009663591259†L287-L289】【773529381107959†L243-L269】. Some classes grant
/// expertise, doubling the proficiency bonus.
class Skills {
  static const List<SkillDefinition> all = [
    SkillDefinition('Acrobatics', Ability.dexterity),
    SkillDefinition('Animal Handling', Ability.wisdom),
    SkillDefinition('Arcana', Ability.intelligence),
    SkillDefinition('Athletics', Ability.strength),
    SkillDefinition('Deception', Ability.charisma),
    SkillDefinition('History', Ability.intelligence),
    SkillDefinition('Insight', Ability.wisdom),
    SkillDefinition('Intimidation', Ability.charisma),
    SkillDefinition('Investigation', Ability.intelligence),
    SkillDefinition('Medicine', Ability.wisdom),
    SkillDefinition('Nature', Ability.intelligence),
    SkillDefinition('Perception', Ability.wisdom),
    SkillDefinition('Performance', Ability.charisma),
    SkillDefinition('Persuasion', Ability.charisma),
    SkillDefinition('Religion', Ability.intelligence),
    SkillDefinition('Sleight of Hand', Ability.dexterity),
    SkillDefinition('Stealth', Ability.dexterity),
    SkillDefinition('Survival', Ability.wisdom),
  ];
}