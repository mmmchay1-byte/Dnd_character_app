import 'ability.dart';

/// Represents a playable race in D&D 5e.
class Race {
  final String name;
  final int speed;
  final Map<Ability, int> abilityBonuses;
  final List<String> traits;
  final List<Subrace> subraces;

  Race({required this.name, required this.speed, required this.abilityBonuses, required this.traits, required this.subraces});

  factory Race.fromJson(Map<String, dynamic> json) {
    final Map<Ability, int> bonuses = {};
    if (json['ability_bonuses'] is Map<String, dynamic>) {
      (json['ability_bonuses'] as Map<String, dynamic>).forEach((key, value) {
        final ability = _parseAbility(key);
        if (ability != null && value is int) {
          bonuses[ability] = value;
        }
      });
    }
    return Race(
      name: json['name'] as String,
      speed: json['speed'] as int,
      abilityBonuses: bonuses,
      traits: (json['traits'] as List<dynamic>).cast<String>(),
      subraces: (json['subraces'] as List<dynamic>).map((e) => Subrace.fromJson(e as Map<String, dynamic>)).toList(),
    );
  }

  /// Look up an ability from its string label.
  static Ability? _parseAbility(String name) {
    switch (name.toLowerCase()) {
      case 'strength':
        return Ability.strength;
      case 'dexterity':
        return Ability.dexterity;
      case 'constitution':
        return Ability.constitution;
      case 'intelligence':
        return Ability.intelligence;
      case 'wisdom':
        return Ability.wisdom;
      case 'charisma':
        return Ability.charisma;
      default:
        return null;
    }
  }
}

/// Represents a subrace, which augments a base race with additional ability
/// bonuses and traits.
class Subrace {
  final String name;
  final Map<Ability, int> abilityBonuses;
  final List<String> traits;

  Subrace({required this.name, required this.abilityBonuses, required this.traits});

  factory Subrace.fromJson(Map<String, dynamic> json) {
    final Map<Ability, int> bonuses = {};
    if (json['ability_bonuses'] is Map<String, dynamic>) {
      (json['ability_bonuses'] as Map<String, dynamic>).forEach((key, value) {
        final ability = Race._parseAbility(key);
        if (ability != null && value is int) {
          bonuses[ability] = value;
        }
      });
    }
    return Subrace(
      name: json['name'] as String,
      abilityBonuses: bonuses,
      traits: (json['traits'] as List<dynamic>).cast<String>(),
    );
  }
}