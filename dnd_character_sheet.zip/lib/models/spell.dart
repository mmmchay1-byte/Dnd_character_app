/// Represents a spell from the 5e spell list.
class Spell {
  final String name;
  final int level;
  final String school;
  final String castingTime;
  final String range;
  final List<String> components;
  final String duration;
  final List<String> classes;
  final String description;

  Spell({
    required this.name,
    required this.level,
    required this.school,
    required this.castingTime,
    required this.range,
    required this.components,
    required this.duration,
    required this.classes,
    required this.description,
  });

  factory Spell.fromJson(Map<String, dynamic> json) => Spell(
        name: json['name'] as String,
        level: json['level'] as int,
        school: json['school'] as String,
        castingTime: json['casting_time'] as String,
        range: json['range'] as String,
        components: (json['components'] as List<dynamic>).cast<String>(),
        duration: json['duration'] as String,
        classes: (json['classes'] as List<dynamic>).cast<String>(),
        description: json['description'] as String,
      );
}