/// Represents the six ability scores in D&D 5e.
enum Ability {
  strength,
  dexterity,
  constitution,
  intelligence,
  wisdom,
  charisma,
}

/// Utility functions for ability scores.
class AbilityUtils {
  /// Returns a human‑readable label for the given ability.
  static String label(Ability ability) {
    switch (ability) {
      case Ability.strength:
        return 'Strength';
      case Ability.dexterity:
        return 'Dexterity';
      case Ability.constitution:
        return 'Constitution';
      case Ability.intelligence:
        return 'Intelligence';
      case Ability.wisdom:
        return 'Wisdom';
      case Ability.charisma:
        return 'Charisma';
    }
  }

  /// Computes the ability modifier according to the D&D 5e rules.
  ///
  /// The modifier is determined by subtracting 10 from the ability score,
  /// dividing the result by 2, and rounding down (floor). See the official
  /// rules for details【103009663591259†L287-L289】.
  static int modifier(int score) {
    return ((score - 10) / 2).floor();
  }
}