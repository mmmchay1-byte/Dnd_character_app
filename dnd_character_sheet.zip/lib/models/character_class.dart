import 'ability.dart';

/// Represents a playable class in D&D 5e.
class CharacterClass {
  final String name;
  final String hitDie;
  final List<Ability> primaryAbilities;
  final List<Ability> savingThrows;
  final List<String> skillChoices;
  final int numSkillChoices;
  final List<List<String>> equipmentChoices;
  final bool spellcasting;
  final Ability? spellAbility;
  final Map<int, List<String>> features;

  CharacterClass({
    required this.name,
    required this.hitDie,
    required this.primaryAbilities,
    required this.savingThrows,
    required this.skillChoices,
    required this.numSkillChoices,
    required this.equipmentChoices,
    required this.spellcasting,
    this.spellAbility,
    required this.features,
  });

  factory CharacterClass.fromJson(Map<String, dynamic> json) {
    // Parse ability names to enum.
    List<Ability> parseAbilities(List<dynamic> raw) {
      return raw.map((e) {
        final name = e.toString();
        switch (name.toLowerCase()) {
          case 'strength':
            return Ability.strength;
          case 'dexterity':
            return Ability.dexterity;
          case 'constitution':
            return Ability.constitution;
          case 'intelligence':
            return Ability.intelligence;
          case 'wisdom':
            return Ability.wisdom;
          case 'charisma':
            return Ability.charisma;
          default:
            return Ability.strength;
        }
      }).toList();
    }

    final primary = parseAbilities((json['primary_abilities'] as List<dynamic>));
    final saving = parseAbilities((json['saving_throws'] as List<dynamic>));
    Ability? spellAbility;
    if (json.containsKey('spell_ability') && json['spell_ability'] != null) {
      spellAbility = parseAbilities([json['spell_ability']]).first;
    }
    final featuresMap = <int, List<String>>{};
    (json['features'] as Map<String, dynamic>).forEach((key, value) {
      final intLevel = int.tryParse(key) ?? 1;
      featuresMap[intLevel] = (value as List<dynamic>).cast<String>();
    });
    return CharacterClass(
      name: json['name'] as String,
      hitDie: json['hit_die'] as String,
      primaryAbilities: primary,
      savingThrows: saving,
      skillChoices: (json['skill_choices'] as List<dynamic>).cast<String>(),
      numSkillChoices: json['num_skill_choices'] as int,
      equipmentChoices: (json['equipment_choices'] as List<dynamic>).map((e) => (e as List<dynamic>).cast<String>()).toList(),
      spellcasting: json['spellcasting'] as bool,
      spellAbility: spellAbility,
      features: featuresMap,
    );
  }
}