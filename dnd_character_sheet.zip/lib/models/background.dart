/// Represents a character background, providing skill proficiencies, languages,
/// equipment and a feature.
class Background {
  final String name;
  final List<String> skillProficiencies;
  final List<String> toolProficiencies;
  final List<String> languages;
  final List<String> equipment;
  final String feature;
  final List<String> personalityTraits;
  final List<String> ideals;
  final List<String> bonds;
  final List<String> flaws;

  Background({
    required this.name,
    required this.skillProficiencies,
    required this.toolProficiencies,
    required this.languages,
    required this.equipment,
    required this.feature,
    required this.personalityTraits,
    required this.ideals,
    required this.bonds,
    required this.flaws,
  });

  factory Background.fromJson(Map<String, dynamic> json) => Background(
        name: json['name'] as String,
        skillProficiencies: (json['skill_proficiencies'] as List<dynamic>).cast<String>(),
        toolProficiencies: (json['tool_proficiencies'] as List<dynamic>).cast<String>(),
        languages: (json['languages'] as List<dynamic>).cast<String>(),
        equipment: (json['equipment'] as List<dynamic>).cast<String>(),
        feature: json['feature'] as String,
        personalityTraits: (json['personality_traits'] as List<dynamic>).cast<String>(),
        ideals: (json['ideals'] as List<dynamic>).cast<String>(),
        bonds: (json['bonds'] as List<dynamic>).cast<String>(),
        flaws: (json['flaws'] as List<dynamic>).cast<String>(),
      );
}