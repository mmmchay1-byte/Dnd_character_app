import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import '../models/race.dart';
import '../models/character_class.dart';
import '../models/background.dart';
import '../models/spell.dart';

/// Service responsible for loading D&D data from JSON files in assets.
class DataService {
  static List<Race>? _races;
  static List<CharacterClass>? _classes;
  static List<Background>? _backgrounds;
  static List<Spell>? _spells;

  /// Loads races from assets if not already loaded.
  static Future<List<Race>> getRaces() async {
    if (_races != null) return _races!;
    final jsonStr = await rootBundle.loadString('assets/data/races.json');
    final List<dynamic> data = jsonDecode(jsonStr);
    _races = data.map((e) => Race.fromJson(e as Map<String, dynamic>)).toList();
    return _races!;
  }

  static Future<List<CharacterClass>> getClasses() async {
    if (_classes != null) return _classes!;
    final jsonStr = await rootBundle.loadString('assets/data/classes.json');
    final List<dynamic> data = jsonDecode(jsonStr);
    _classes = data.map((e) => CharacterClass.fromJson(e as Map<String, dynamic>)).toList();
    return _classes!;
  }

  static Future<List<Background>> getBackgrounds() async {
    if (_backgrounds != null) return _backgrounds!;
    final jsonStr = await rootBundle.loadString('assets/data/backgrounds.json');
    final List<dynamic> data = jsonDecode(jsonStr);
    _backgrounds = data.map((e) => Background.fromJson(e as Map<String, dynamic>)).toList();
    return _backgrounds!;
  }

  static Future<List<Spell>> getSpells() async {
    if (_spells != null) return _spells!;
    final jsonStr = await rootBundle.loadString('assets/data/spells.json');
    final List<dynamic> data = jsonDecode(jsonStr);
    _spells = data.map((e) => Spell.fromJson(e as Map<String, dynamic>)).toList();
    return _spells!;
  }
}