import 'dart:math';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/ability.dart';
import '../models/character.dart';
import '../models/race.dart';
import '../models/character_class.dart';
import '../models/background.dart';
import '../models/spell.dart';
import '../providers/character_provider.dart';
import '../services/data_service.dart';

/// A multi‑step wizard that guides the user through creating a new character.
class CharacterCreationScreen extends StatefulWidget {
  const CharacterCreationScreen({super.key});

  @override
  State<CharacterCreationScreen> createState() => _CharacterCreationScreenState();
}

class _CharacterCreationScreenState extends State<CharacterCreationScreen> {
  int _currentStep = 0;
  // Data loaded from JSON.
  List<Race>? _races;
  List<CharacterClass>? _classes;
  List<Background>? _backgrounds;

  // Selected values.
  Race? _selectedRace;
  Subrace? _selectedSubrace;
  CharacterClass? _selectedClass;
  Background? _selectedBackground;
  Map<Ability, int> _abilityScores = {};
  final TextEditingController _nameController = TextEditingController();

  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final races = await DataService.getRaces();
    final classes = await DataService.getClasses();
    final backgrounds = await DataService.getBackgrounds();
    setState(() {
      _races = races;
      _classes = classes;
      _backgrounds = backgrounds;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Create Character')),
      body: Stepper(
        currentStep: _currentStep,
        onStepContinue: _nextStep,
        onStepCancel: _prevStep,
        steps: [
          Step(
            title: const Text('Name'),
            isActive: _currentStep >= 0,
            content: TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Character Name'),
            ),
          ),
          Step(
            title: const Text('Race'),
            isActive: _currentStep >= 1,
            content: Column(
              children: _races!.map((race) {
                return RadioListTile<Race>(
                  title: Text(race.name),
                  subtitle: Text('Speed ${race.speed} ft'),
                  value: race,
                  groupValue: _selectedRace,
                  onChanged: (val) {
                    setState(() {
                      _selectedRace = val;
                      _selectedSubrace = null;
                    });
                  },
                );
              }).toList(),
            ),
          ),
          Step(
            title: const Text('Subrace'),
            isActive: _currentStep >= 2,
            content: _selectedRace == null || _selectedRace!.subraces.isEmpty
                ? const Text('No subraces available.')
                : Column(
                    children: _selectedRace!.subraces.map((sr) {
                      return RadioListTile<Subrace>(
                        title: Text(sr.name),
                        subtitle: Text(sr.traits.join(', ')),
                        value: sr,
                        groupValue: _selectedSubrace,
                        onChanged: (val) {
                          setState(() => _selectedSubrace = val);
                        },
                      );
                    }).toList(),
                  ),
          ),
          Step(
            title: const Text('Class'),
            isActive: _currentStep >= 3,
            content: Column(
              children: _classes!.map((cls) {
                return RadioListTile<CharacterClass>(
                  title: Text(cls.name),
                  subtitle: Text('Hit Die ${cls.hitDie}'),
                  value: cls,
                  groupValue: _selectedClass,
                  onChanged: (val) {
                    setState(() => _selectedClass = val);
                  },
                );
              }).toList(),
            ),
          ),
          Step(
            title: const Text('Background'),
            isActive: _currentStep >= 4,
            content: Column(
              children: _backgrounds!.map((bg) {
                return RadioListTile<Background>(
                  title: Text(bg.name),
                  subtitle: Text('Skills: ${bg.skillProficiencies.join(', ')}'),
                  value: bg,
                  groupValue: _selectedBackground,
                  onChanged: (val) {
                    setState(() => _selectedBackground = val);
                  },
                );
              }).toList(),
            ),
          ),
          Step(
            title: const Text('Abilities'),
            isActive: _currentStep >= 5,
            content: _buildAbilityAllocation(),
          ),
          Step(
            title: const Text('Review'),
            isActive: _currentStep >= 6,
            content: _buildReview(),
          ),
        ],
      ),
    );
  }

  Widget _buildAbilityAllocation() {
    // Standard array to assign.
    final List<int> standardArray = [15, 14, 13, 12, 10, 8];
    final assigned = Set<int>.from(_abilityScores.values);
    return Column(
      children: Ability.values.map((ability) {
        return Row(
          children: [
            Expanded(child: Text(AbilityUtils.label(ability))),
            DropdownButton<int>(
              value: _abilityScores[ability],
              hint: const Text('Select'),
              items: standardArray.map((score) {
                return DropdownMenuItem<int>(
                  value: score,
                  enabled: !assigned.contains(score) || _abilityScores[ability] == score,
                  child: Text(score.toString()),
                );
              }).toList(),
              onChanged: (value) {
                setState(() {
                  _abilityScores[ability] = value!;
                });
              },
            ),
          ],
        );
      }).toList(),
    );
  }

  Widget _buildReview() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Name: ${_nameController.text}'),
        Text('Race: ${_selectedRace?.name ?? ''}'),
        if (_selectedSubrace != null) Text('Subrace: ${_selectedSubrace!.name}'),
        Text('Class: ${_selectedClass?.name ?? ''}'),
        Text('Background: ${_selectedBackground?.name ?? ''}'),
        const SizedBox(height: 8),
        Text('Abilities:'),
        ...Ability.values.map((ab) => Text('${AbilityUtils.label(ab)}: ${_abilityScores[ab] ?? '-'}')),
        const SizedBox(height: 16),
        ElevatedButton(
          onPressed: _canFinish() ? _finishCreation : null,
          child: const Text('Save Character'),
        ),
      ],
    );
  }

  bool _canFinish() {
    return _nameController.text.isNotEmpty &&
        _selectedRace != null &&
        _selectedClass != null &&
        _selectedBackground != null &&
        _abilityScores.length == Ability.values.length;
  }

  void _nextStep() {
    if (_currentStep == 6) return;
    setState(() {
      _currentStep = min(_currentStep + 1, 6);
    });
  }

  void _prevStep() {
    if (_currentStep == 0) {
      Navigator.of(context).pop();
      return;
    }
    setState(() {
      _currentStep = max(_currentStep - 1, 0);
    });
  }

  void _finishCreation() {
    final provider = Provider.of<CharacterProvider>(context, listen: false);
    final newChar = Character(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      name: _nameController.text,
      race: _selectedRace!,
      subrace: _selectedSubrace,
      background: _selectedBackground!,
      classLevels: {_selectedClass!: 1},
      abilityScores: _abilityScores,
      skillProficiencies: {
        for (final skill in _selectedBackground!.skillProficiencies)
          skill: true
      },
      skillExpertise: {},
      equipment: [],
      knownSpells: [],
      preparedSpells: [],
    );
    provider.addCharacter(newChar);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Character created!')));
    Navigator.of(context).pop();
  }
}