import 'package:flutter/material.dart';
import '../models/character.dart';
import '../models/skill.dart';
import '../models/ability.dart';

/// Displays a character sheet with multiple tabs.
class CharacterSheetScreen extends StatefulWidget {
  final Character character;
  const CharacterSheetScreen({super.key, required this.character});

  @override
  State<CharacterSheetScreen> createState() => _CharacterSheetScreenState();
}

class _CharacterSheetScreenState extends State<CharacterSheetScreen> with SingleTickerProviderStateMixin {
  late TabController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TabController(length: 6, vsync: this);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = widget.character;
    return Scaffold(
      appBar: AppBar(
        title: Text(c.name),
        bottom: TabBar(
          controller: _controller,
          isScrollable: true,
          tabs: const [
            Tab(text: 'Overview'),
            Tab(text: 'Abilities'),
            Tab(text: 'Skills'),
            Tab(text: 'Inventory'),
            Tab(text: 'Spells'),
            Tab(text: 'Notes'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _controller,
        children: [
          _buildOverviewTab(c),
          _buildAbilitiesTab(c),
          _buildSkillsTab(c),
          _buildInventoryTab(c),
          _buildSpellsTab(c),
          _buildNotesTab(c),
        ],
      ),
    );
  }

  Widget _buildOverviewTab(Character c) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Race: ${c.race.name}${c.subrace != null ? ' (${c.subrace!.name})' : ''}', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Text('Class Levels:'),
          ...c.classLevels.entries.map((e) => Text('${e.key.name} ${e.value}')), 
          const SizedBox(height: 8),
          Text('Level: ${c.level} (Proficiency Bonus +${c.proficiencyBonus})'),
          const SizedBox(height: 8),
          Text('Hit Points: ${c.maxHitPoints}'),
          const SizedBox(height: 8),
          Text('Speed: ${c.race.speed + (c.subrace?.traits.any((t) => t.contains("Fleet of Foot")) == true ? 5 : 0)} ft'),
          const SizedBox(height: 8),
          Text('Initiative: ${c.abilityModifier(Ability.dexterity) >= 0 ? '+' : ''}${c.abilityModifier(Ability.dexterity)}'),
        ],
      ),
    );
  }

  Widget _buildAbilitiesTab(Character c) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: Ability.values.map((ability) {
        final score = c.totalAbilityScore(ability);
        final mod = c.abilityModifier(ability);
        return ListTile(
          title: Text(AbilityUtils.label(ability)),
          subtitle: Text('Score: $score'),
          trailing: Text(mod >= 0 ? '+$mod' : '$mod'),
        );
      }).toList(),
    );
  }

  Widget _buildSkillsTab(Character c) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: Skills.all.map((skill) {
        final bonus = c.skillBonus(skill.name);
        return CheckboxListTile(
          title: Text(skill.name),
          subtitle: Text('${AbilityUtils.label(skill.ability)}'),
          value: c.isProficientIn(skill.name),
          onChanged: (val) {
            setState(() {
              c.skillProficiencies[skill.name] = val ?? false;
            });
          },
          secondary: Text(bonus >= 0 ? '+$bonus' : '$bonus'),
        );
      }).toList(),
    );
  }

  Widget _buildInventoryTab(Character c) {
    final controller = TextEditingController();
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            itemCount: c.equipment.length,
            itemBuilder: (context, index) {
              final item = c.equipment[index];
              return ListTile(
                title: Text(item),
                trailing: IconButton(
                  icon: const Icon(Icons.delete),
                  onPressed: () {
                    setState(() {
                      c.equipment.removeAt(index);
                    });
                  },
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  controller: controller,
                  decoration: const InputDecoration(labelText: 'Add Item'),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.add),
                onPressed: () {
                  final text = controller.text.trim();
                  if (text.isNotEmpty) {
                    setState(() {
                      c.equipment.add(text);
                      controller.clear();
                    });
                  }
                },
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSpellsTab(Character c) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: c.knownSpells.isEmpty
          ? [const Text('No spells known.')]
          : c.knownSpells.map((spell) {
              return ListTile(
                title: Text(spell.name),
                subtitle: Text('Level ${spell.level} • ${spell.school}'),
                onTap: () {
                  showDialog(
                    context: context,
                    builder: (context) => AlertDialog(
                      title: Text(spell.name),
                      content: SingleChildScrollView(child: Text(spell.description)),
                      actions: [
                        TextButton(
                          onPressed: () => Navigator.pop(context),
                          child: const Text('Close'),
                        ),
                      ],
                    ),
                  );
                },
              );
            }).toList(),
    );
  }

  Widget _buildNotesTab(Character c) {
    final controller = TextEditingController();
    // For demonstration we simply store notes as additional equipment items prefixed.
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          const Text('Notes'),
          const SizedBox(height: 8),
          Expanded(
            child: TextField(
              controller: controller,
              maxLines: null,
              decoration: const InputDecoration(border: OutlineInputBorder()),
              onChanged: (value) {
                // In a full app, this would persist notes separately.
              },
            ),
          ),
        ],
      ),
    );
  }
}