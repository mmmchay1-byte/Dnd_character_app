import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'models/character.dart';
import 'providers/character_provider.dart';
import 'services/data_service.dart';
import 'screens/home_screen.dart';
import 'screens/character_creation_screen.dart';
import 'screens/character_sheet_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Initialize Hive.
  await Hive.initFlutter();
  // Optionally register Hive adapters here if implementing custom serialization.
  final characterProvider = CharacterProvider();
  await characterProvider.init();
  runApp(MyApp(characterProvider: characterProvider));
}

class MyApp extends StatelessWidget {
  final CharacterProvider characterProvider;

  const MyApp({super.key, required this.characterProvider});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider<CharacterProvider>.value(value: characterProvider),
      ],
      child: MaterialApp(
        title: 'D&D Character Sheet',
        theme: ThemeData(
          brightness: Brightness.light,
          primarySwatch: Colors.indigo,
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        ),
        darkTheme: ThemeData.dark().copyWith(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo, brightness: Brightness.dark),
        ),
        themeMode: ThemeMode.system,
        home: const HomeScreen(),
        routes: {
          '/create': (_) => const CharacterCreationScreen(),
        },
      ),
    );
  }
}